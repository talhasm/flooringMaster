package com.jdm.flooring.service;

public class DateAlreadyPassedException extends Exception {

    public DateAlreadyPassedException(String message) {
        super(message);
    }

}
