package com.jdm.flooring.service;

public class TaxCodeViolationException extends Exception {

    public TaxCodeViolationException(String message) {
        super(message);
    }

}
