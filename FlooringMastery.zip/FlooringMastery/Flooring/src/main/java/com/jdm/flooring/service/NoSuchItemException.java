package com.jdm.flooring.service;

public class NoSuchItemException extends Exception {

    public NoSuchItemException(String message) {
        super(message);
    }

}
