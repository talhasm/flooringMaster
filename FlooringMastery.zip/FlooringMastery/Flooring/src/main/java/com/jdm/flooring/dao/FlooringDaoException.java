package com.jdm.flooring.dao;

public class FlooringDaoException extends Exception {

    public FlooringDaoException(String message) {
        super(message);
    }

}
